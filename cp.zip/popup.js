(
()=>{
    "use strict";
    !function(){const t={auto_open:0,auto_solve:!0,click_delay_time:300,solve_delay_time:3e3};
    function s(){chrome.storage.local.get(null,(async s=>{const e=Array.from(document.getElementsByClassName("settings_toggle")),o=Array.from(document.getElementsByClassName("settings_text"));
    for(const e of Object.keys(t))void 0===s[e]&&(await chrome.storage.local.set({[e]:t[e]}),s[e]=t[e]);
    for(let t=0;t<e.length;t++){const n=e[t],a=o[t];n.classList.remove("on","off"),n.classList.add(s[n.dataset.settings]?"on":"off"),a.value=s[a.dataset.settings]}}))
    ;const s=async t=>{var s=t.classList.contains("settings_toggle")?t.classList.contains("off"):t.value;await chrome.storage.local.set({[t.dataset.settings]:s}),t.classList.contains("settings_toggle")&&(t.classList.remove("on","off"),t.classList.add(s?"on":"off"))};for(const t of document.querySelectorAll(".settings_toggle, .settings_text"))t.classList.contains("settings_toggle")?t.addEventListener("click",(()=>s(t))):t.classList.contains("settings_text")&&t.addEventListener("input",(()=>s(t)))}document.addEventListener("DOMContentLoaded",s)}()
    }
)();